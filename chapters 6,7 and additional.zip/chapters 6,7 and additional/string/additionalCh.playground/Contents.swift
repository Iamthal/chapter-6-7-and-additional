import Cocoa

//Gold Chall one

var emoji = "👨‍👩‍👦,👨‍👩‍👦,👩‍❤️‍👨,👨‍👩‍👧‍👦,👨‍👩‍👦‍👦,👨‍👩‍👧‍👧"
var Boy = 0

for k in emoji.unicodeScalars {
    let emojis = String (format: "%04X", k.value)
    if emojis.contains("1F466"){
        Boy += 1
    }
   
}
print("the number of boys is :\(Boy)")


//Gold Chall two


let num1: String = ""
for num1 in 0 ... 25000{
    print(num1)
}
let num2: String = ""
for num2 in 0 ... 50000{
    print(num2)
}
let num3: String = ""
for num3 in 0 ... 100000{
    print(num3)
}
let num4: String = ""
for num4 in 0 ... 200000{
    print(num4)
}

    let start = Date()
    num4.count
    let end = Date()
    let time = end.timeIntervalSince(start)




