import Cocoa

let empty = ""
var a = empty.startIndex
var b = empty.endIndex

if a == b {
    print ("true")
} else {
    print ("false")
}

var Replace: String = "Hello"
var unicodeScalarsString = ""
for s in Replace.unicodeScalars {
    var unicode = String(format: "%04X", s.value)
    unicodeScalarsString += "\\u{\(unicode)}"
}
print (unicodeScalarsString)








